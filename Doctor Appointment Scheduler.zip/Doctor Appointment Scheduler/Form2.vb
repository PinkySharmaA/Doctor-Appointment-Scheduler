﻿Public Class Form2

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Pinky" And TextBox2.Text = "123" Then
            Me.Hide()
            MessageBox.Show("You Logged in as Admin")
            Form5.Show()
        Else
            MessageBox.Show("Recheck The details")
        End If

    End Sub
End Class