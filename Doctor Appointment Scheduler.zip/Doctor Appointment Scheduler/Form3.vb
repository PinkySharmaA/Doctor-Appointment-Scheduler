﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-5HCEJKD\SQLEXPRESS;Initial Catalog=userreg;Integrated Security=True;Trust Server Certificate=True")
        Dim cmd As SqlCommand = New SqlCommand("INSERT INTO [dbo].[reg]
           ([first name]
           ,[last name]
           ,[gender]
           ,[phone number]
           ,[username]
           ,[password])
     VALUES
           ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + ComboBox1.SelectedItem.ToString() + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')", con)
        con.Open()
        cmd.ExecuteNonQuery()
        MessageBox.Show("you have registered successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        con.Close()

    End Sub
End Class